package Filters;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.core.Size;

public class Laplacian{
	

	public void run(String picPath){
		System.out.println("Initiating Laplacing...");
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		Mat gray = Imgcodecs.imread(picPath, 0);
		Imgproc.Laplacian(gray, gray, gray.depth());
		
		String newPath = picPath.replace("/Users/markeschweiler/Downloads/sculptureTest/", "/Users/markeschweiler/Downloads/sculptureTest/zzzz/" ); 
		Imgcodecs.imwrite(newPath, gray);
		System.out.println("File written... ("+newPath+")");
		System.out.println("Laplacing Completed...");
		
	}
}