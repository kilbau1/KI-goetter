import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import Filters.Laplacian;

public class Application {

	public static void main (String[] args) {
		//String picPath = "/Users/markeschweiler/Downloads/zeus.jpg";
		
		File f = new File("/Users/markeschweiler/Downloads/sculptureTest");
		File[] fileArray = f.listFiles();
		//String picPath = fileArray[2].getAbsolutePath();
		//System.out.println(picPath);
		
		
		for (int i = 1; i<fileArray.length-2; i++){
			
		String picPath = fileArray[i].getAbsolutePath();
		
		Detectors d = new Detectors();
		Boolean isSculpture= d.run(picPath);
		if (isSculpture){
			System.out.println("isSculpture: "+isSculpture);
			System.out.println("Start filtering...");
			Laplacian l = new Laplacian();
			l.run(picPath);
			System.out.println("------------------------------------------------------");
		} else{
			System.out.println("isSculpture: "+isSculpture);
			System.out.println("Abort filtering...");
			System.out.println("------------------------------------------------------");
		}
    	
    }
		System.out.println("Finished...");
	}

}
