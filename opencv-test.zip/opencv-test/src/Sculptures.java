import java.text.DecimalFormat;
public class Sculptures {
	public boolean sculptureDetected(int fd, int ubd, int lbd, double cd){
		DecimalFormat df = new DecimalFormat ("0.0000000000");
		double faceIndicator = 1.0 / fd*0.75;
		double upperbodyIndicator = 1.0 / ubd*0.75;
		double lowerbodyIndicator = 1.0 / lbd*0.5;
		double colorIndicator = cd / 100*0.8;
		if (fd == 0){
			faceIndicator = 0;
		}
		if (ubd == 0){
			upperbodyIndicator = 0;
		}
		if (lbd == 0){
			lowerbodyIndicator = 0;
		}
		if (cd == 0){
			colorIndicator = 0;
		}
		System.out.println("Face indicator value: "+df.format(faceIndicator));
		System.out.println("Upper body indicator value: "+df.format(upperbodyIndicator));
		System.out.println("Lower body indicator value: "+df.format(lowerbodyIndicator));
		System.out.println("Color indicator value: "+df.format(colorIndicator));
		double sculptureIndicator = (faceIndicator)+(upperbodyIndicator)+(lowerbodyIndicator)+(colorIndicator);
		System.out.println("sculpture indicator value: "+df.format(sculptureIndicator));
		if (sculptureIndicator >= 1.0){
			return true;
		}
		else
		return false;
	}
}
