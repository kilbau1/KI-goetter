
import Detectors.ColorDetector;
import Detectors.FaceDetector;
import Detectors.LowerBodyDetector;
import Detectors.UpperBodyDetector;

public class Detectors {
	
	public boolean run(String picPath){
	Sculptures s = new Sculptures();
	FaceDetector fd = new FaceDetector();
	UpperBodyDetector ubd = new UpperBodyDetector();
	LowerBodyDetector lbd = new LowerBodyDetector();
	ColorDetector cd = new ColorDetector();
	System.out.println("Starting...");
	System.out.println("Loading... ("+picPath+")");
	
	Integer detectedFaces = fd.run(picPath);
	
	
	Integer detectedUpperBodies = ubd.run(picPath);
	
	
	Integer detectedLowerBodies = lbd.run(picPath);
	
	Double detectedColorPercentage = cd.run(picPath);
	boolean isSculptureDetected = s.sculptureDetected(detectedFaces, detectedUpperBodies, detectedLowerBodies, detectedColorPercentage); //Platzhalter
	
	
	return isSculptureDetected;
	}
}
