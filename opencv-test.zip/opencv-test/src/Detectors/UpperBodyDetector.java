package Detectors;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.objdetect.CascadeClassifier;
 
public class UpperBodyDetector {
		
    public int run(String path) {
    	System.out.println(String.format("Searching upper bodies..."));
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
      
       //upperbody
        CascadeClassifier upperBodyDetector = new CascadeClassifier("/Users/markeschweiler/downloads/opencv-3.2.0/data/haarcascades/haarcascade_upperbody.xml");
 
        Mat image = Imgcodecs.imread(path);
 
        MatOfRect upperBodyDetections = new MatOfRect();
        upperBodyDetector.detectMultiScale(image, upperBodyDetections);
       
        System.out.println(String.format("Detected upper bodies:  "+upperBodyDetections.toArray().length));
        return upperBodyDetections.toArray().length; 
    }
    
 
  
}