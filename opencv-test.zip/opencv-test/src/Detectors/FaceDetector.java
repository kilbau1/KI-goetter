package Detectors;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.objdetect.CascadeClassifier;
 
public class FaceDetector {
		
    public int run(String path) {
    	System.out.println(String.format("Searching faces..."));
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
      
        CascadeClassifier faceDetector = new CascadeClassifier("/Users/markeschweiler/downloads/opencv-3.2.0/data/haarcascades/haarcascade_frontalface_alt.xml");
 
        Mat image = Imgcodecs.imread(path);
 
        MatOfRect faceDetections = new MatOfRect();
        faceDetector.detectMultiScale(image, faceDetections);
        System.out.println(String.format("Detected faces:  "+faceDetections.toArray().length));
        return faceDetections.toArray().length;
    }
    
 
  
}