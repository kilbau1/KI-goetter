package Detectors;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.objdetect.CascadeClassifier;
 
public class LowerBodyDetector {
		
    public int run(String path) {
    	System.out.println(String.format("Searching lower bodies..."));
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
      
       //upperbody
        CascadeClassifier lowerBodyDetector = new CascadeClassifier("/Users/markeschweiler/downloads/opencv-3.2.0/data/haarcascades/haarcascade_lowerbody.xml");
 
        Mat image = Imgcodecs.imread(path);
 
        MatOfRect lowerBodyDetections = new MatOfRect();
        lowerBodyDetector.detectMultiScale(image, lowerBodyDetections);
        System.out.println(String.format("Detected lower bodies:  "+lowerBodyDetections.toArray().length));
   
        return lowerBodyDetections.toArray().length; 
    }
    
 
  
}