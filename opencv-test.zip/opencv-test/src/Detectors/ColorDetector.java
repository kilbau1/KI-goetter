package Detectors;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.video.BackgroundSubtractor;
import org.opencv.video.BackgroundSubtractorKNN;
import org.opencv.video.BackgroundSubtractorMOG2;
import org.opencv.video.Video;
import org.opencv.core.Range;
import org.opencv.core.Scalar;



public class ColorDetector {

	
	public double run(String picPath){
		System.out.println("Searching colors...");
		
	

    Mat image = Imgcodecs.imread(picPath);
    
    
    Mat outputImage = new Mat();
    Core.inRange(image, new Scalar(140, 100, 85), new Scalar(255, 255, 255), outputImage);
    int colorDetected =0;
    
    for (int i = 0; i < outputImage.height(); i++){
        for (int j = 0; j < outputImage.width(); j++) {
            double[] data = outputImage.get(i, j);
            //System.out.println("r:"+data[0]);
            if (data[0]==255){
            	colorDetected++;
            }    
        }	
        } 
   
    //Hintergrund-Subtraktion: Alles was in der Subtraktion schwarz ist = Ignorieren! 
    //Alles was nicht schwarz soll vom ColorDetector analysiert werden
    //"%" der richtigen Range kommen als Indiz hinein 

             
   
    
    /*BackgroundSubtractor backgroundSubtractor=Video.createBackgroundSubtractorKNN();
      


              Mat fgMask=new Mat();
              
              backgroundSubtractor.apply(image, fgMask);

              Mat output=new Mat();
              image.copyTo(output,fgMask);*/
    		int outputSize= outputImage.width()*outputImage.height();
    		double outputSize2= outputImage.width()*outputImage.height();
    		double percentage= (colorDetected/outputSize2)*100;
    		System.out.println("Colors Detected: "+ colorDetected+" of "+outputSize+ "... ("+percentage+"%)"); 
    		String newPath = picPath.replace("/Users/markeschweiler/Downloads/sculptureTest/", "/Users/markeschweiler/Downloads/sculptureTest/zzzzz/" ); 
       		Imgcodecs.imwrite(newPath, outputImage);
       		System.out.println("File written... ("+newPath+")");
    		System.out.println("Color Detection completed...");
    		
    		return percentage;
	}

			
}
             
        
        	

    
    /*for (int i = 0; i < image.height(); i++)
        for (int j = 0; j < image.width(); j++) {
            double[] data = image.get(i, j);
            //System.out.println("r:"+data[0]+", g:"+data[1]+", b:"+data[2]);
            
            
            data[0] = data[0] / 2;
            data[1] = data[1] / 2;
            data[2] = data[2] / 2;
           
        }
			
			
        } */
    
    
      

             
               



        

